dojo.declare("PageWindows", wm.Page, {
  start: function() {
 
  },
  // This function gets called by the onclick event for the buttonPopup widget 
  buttonPopupClick: function(inSender, inEvent) {
    try {
       // Check if there is already a selected row in datagrid
       if (this.purchaseDataGrid.hasSelection() == false) {
          // Select first row in grid
          this.purchaseDataGrid.select(0);
       }
       // Parameters are name of page, whether to show chrome, width, height        
       app.pageDialog.showPage("popUpPage",true, 300,300);                    
    } catch(e) {
      console.error('ERROR IN buttonPopupClick: ' + e); 
    } 
  },
  // This function gets called by the onclick event for the buttonAlert widget  
  buttonAlertClick: function(inSender, inEvent) {
    try {
       // Create simple popup using the Javascript alert() function
      alert('WaveMaker is cool!');
    } catch(e) {
      console.error('ERROR IN buttonAlertClick: ' + e); 
    } 
  },
  // This function gets called by the onSelected event for the purchaseDataGrid widget
  purchaseDataGridSelected: function(inSender, inIndex) {
    try {
       console.log('In selected function');
       // Parameters are name of page, whether to show chrome, width, height        
       app.pageDialog.showPage("popUpPage",true, 300,300);              
    } catch(e) {
      console.error('ERROR IN purchaseDataGridSelected: ' + e); 
    } 
  },
  _end: 0
});