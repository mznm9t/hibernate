PageDis.widgets = {
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"500px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						panel1: ["wm.Panel", {"width":"100%","height":"63px","horizontalAlign":"center","verticalAlign":"top"}, {}, {
							buttonDisabled: ["wm.Button", {"caption":"Disabled = True","width":"140px","height":"25px"}, {"onclick":"buttonDisabledClick"}],
							buttonEnabled: ["wm.Button", {"caption":"Disabled = False","width":"140px","height":"25px"}, {"onclick":"buttonEnabledClick"}]
						}],
						layoutContent1: ["wm.Content", {"margin":"10","content":"disabledText"}, {}]
					}],
					spacer12: ["wm.Spacer", {"width":"30px"}, {}],
					panel2: ["wm.Panel", {"width":"100%","height":"200px","horizontalAlign":"left","verticalAlign":"top","border":"5","borderColor":"#999999","scrollX":true,"scrollY":true}, {}, {
						label5: ["wm.Label", {"caption":"The widgets are  enabled","height":"38px","width":"100%","singleLine":false}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						dateEditor1: ["wm.DateEditor", {"width":"100%","caption":"Enter date","captionSize":"70%"}, {}, {
							editor: ["wm._DateEditor", {}, {}]
						}],
						selectEditor1: ["wm.SelectEditor", {"width":"100%","caption":"Select item","captionSize":"70%"}, {}, {
							editor: ["wm._SelectEditor", {"options":"pick me, no me, no pick me","displayField":"name","dataField":"dataValue"}, {}, {
								optionsVar: ["wm.Variable", {"type":"EntryData"}, {}]
							}]
						}],
						radioButtonEditor1: ["wm.RadioButtonEditor", {"width":"100%","caption":"Choice 1"}, {}, {
							editor: ["wm._RadioButtonEditor", {"radioGroup":"choice","startChecked":true}, {}]
						}],
						radioButtonEditor2: ["wm.RadioButtonEditor", {"width":"100%","caption":"Choice 2"}, {}, {
							editor: ["wm._RadioButtonEditor", {"radioGroup":"choice"}, {}]
						}]
					}],
					spacer10: ["wm.Spacer", {"width":"30px"}, {}],
					pictureWidgetFlex: ["wm.Picture", {"height":"100%","width":"200px","source":"resources/images/disabled.gif"}, {}, {
						binding: ["wm.Binding", {}, {}, {
							wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/disabled.gif\""}, {}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"disabledJSCode"}, {}]
				}]
			}]
		}]
	}]
}