dojo.declare("Temp", wm.Page, {
  start: function() {
    
  },
  button3Click: function(inSender, inEvent) {
    try {
           
        var textVar = 'Selected tab is '+this.tabLayers2.getLayer().getIndex();
        textVar += ' caption is '+this.tabLayers2.getLayerCaption(); 
        this.label1.setCaption(textVar);
    } catch(e) {
      console.error('ERROR IN button3Click: ' + e); 
    } 
  },
  windowButtonClick: function(inSender, inEvent) {
    try {
    // Parameters are name of page, whether to show chrome, width, height 
       
    app.pageDialog.showPage("popUpPage",true, 300,200);             
      
    } catch(e) {
      console.error('ERROR IN windowButtonClick: ' + e); 
    } 
  },
  alertButtonClick: function(inSender, inEvent) {
    try {
    
      alert('WaveMaker is cool!');

      
    } catch(e) {
      console.error('ERROR IN alertButtonClick: ' + e); 
    } 
  },
  verticalButtonClick: function(inSender, inEvent) {
    try {
       this.dojoMenu1.setValue('vertical',true);
      
    } catch(e) {
      console.error('ERROR IN button4Click: ' + e); 
    } 
  },
  horizButtonClick: function(inSender, inEvent) {
    try {
    
       this.dojoMenu1.setValue('vertical',false);     
      
    } catch(e) {
      console.error('ERROR IN horizButtonClick: ' + e); 
    } 
  },
  onDojoMenuThisClick: function(inSender /*,args*/) {
    try {
        // this.dojoMenu1.getDataValue();
        alert(inSender);
      
    } catch(e) {
      console.error('ERROR IN onDojoMenuThisClick: ' + e); 
    } 
  },
  button4Click: function(inSender, inEvent) {
    try {
      this.progressBar1.setProgress(this.progressBar1.getProgress()+10);
      
    } catch(e) {
      console.error('ERROR IN button4Click: ' + e); 
    } 
  },
  button5Click: function(inSender, inEvent) {
    try {
    
     this.feedList1.setValue('url','http://twitter.com/#search?q=wavemaker');
      
    } catch(e) {
      console.error('ERROR IN button5Click: ' + e); 
    } 
  },
  _end: 0
});