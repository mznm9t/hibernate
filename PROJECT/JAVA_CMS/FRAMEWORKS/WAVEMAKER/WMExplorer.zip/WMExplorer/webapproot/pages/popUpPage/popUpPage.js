dojo.declare("popUpPage", wm.Page, {
  start: function() {
    
  },
   // This function is called by the onClick event of the dismissButton widget
  dismissButtonClick: function(inSender, inEvent) {
    try {
       // Dismiss this popup window
       app.pageDialog.dismiss("popUpPage");     
      
    } catch(e) {
      console.error('ERROR IN button1Click: ' + e); 
    } 
  },
  _end: 0
});