dojo.declare("PageDis", wm.Page, {
  start: function() {
    
  },
  // This function gets called by the onclick event for the buttonEnabled widget  
  buttonEnabledClick: function(inSender) {
    // Enable the widgets so they can be edited 
    this.dateEditor1.enable();
    this.selectEditor1.enable();
    this.dateEditor1.enable();
    // This will affect all radio buttons in the group "choice"
    this.radioButtonEditor1.enable();
    this.radioButtonEditor2.enable();    
  },
  // This function gets called by the onclick event for the buttonDisabled  widget  
  buttonDisabledClick: function(inSender) {
    // Disable the widgets so they cannot be edited 
    this.dateEditor1.disable();
    this.selectEditor1.disable();
    this.dateEditor1.disable();
    // This will affect all radio buttons in the group "choice"
    this.radioButtonEditor1.disable();
    this.radioButtonEditor2.disable();    
  },
  _end: 0
});