dojo.declare("PageValid", wm.Page, {
  start: function() {
    
  },
  // This function gets called when the value of a text editor widget changes
  textEditor2Change: function(inSender, inDisplayValue, inDataValue) {
    try {
        var ValidChars = "0123456789.";
        var IsNumber=true;
        var Char;
        var i;
 
        for (i = 0; i < inDataValue.length && IsNumber == true; i++) { 
           Char = inDataValue.charAt(i); 
           if (ValidChars.indexOf(Char) == -1) {
            IsNumber = false;
         }
        }
        if (IsNumber == false) {
           alert('You did not enter a number');
        }
    } catch(e) {
      console.error('ERROR IN textEditor2Change: ' + e); 
    } 
  },
  _end: 0
});