dojo.declare("PageLayout", wm.Page, {
  start: function() {
    
  },
  // This function gets called by the onclick event for the buttonLeft widget  
  buttonLeftClick: function(inSender) {
    // Change the "layoutKind" parameter for the panel to "left-to-right" 
    this.panel2.setValue("layoutKind","left-to-right");  
    this.label5.setCaption("Panel will now layout widgets left-to-right");
  },
  // This function gets called by the onclick event for the buttonLeft widget  
  buttonTopClick: function(inSender) {
    // Change the "layoutKind" parameter for the panel to "left-to-right" 
    this.panel2.setValue("layoutKind","top-to-bottom");  
    this.label5.setCaption("Panel will now layout widgets top-to-bottom");
  },
  _end: 0
});