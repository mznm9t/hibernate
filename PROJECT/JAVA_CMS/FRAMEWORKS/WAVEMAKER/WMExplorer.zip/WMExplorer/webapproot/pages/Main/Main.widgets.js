Main.widgets = {
	editorNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"editorLayer"}, {}]
			}]
		}]
	}],
	validNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"validLayer"}, {}]
			}]
		}]
	}],
	panelNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"panelLayer"}, {}]
			}]
		}]
	}],
	popupNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"popupLayer"}, {}]
			}]
		}]
	}],
	menuNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"menuLayer"}, {}]
			}]
		}]
	}],
	dataNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"dataLayer"}, {}]
			}]
		}]
	}],
	relatedNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"relatedLayer"}, {}]
			}]
		}]
	}],
	navLayerNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"navLayer"}, {}]
			}]
		}]
	}],
	sizingNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"sizingLayer"}, {}]
			}]
		}]
	}],
	layoutNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"layoutLayer"}, {}]
			}]
		}]
	}],
	selectNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"selectLayer"}, {}]
			}]
		}]
	}],
	relToOneNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"relToOneLayer"}, {}]
			}]
		}]
	}],
	showingNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"showingLayer"}, {}]
			}]
		}]
	}],
	disabledNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"disabledLayer"}, {}]
			}]
		}]
	}],
	pieNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"pieLayer"}, {}]
			}]
		}]
	}],
	barNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"barLayer"}, {}]
			}]
		}]
	}],
	gridNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"gridLayer"}, {}]
			}]
		}]
	}],
	filterNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"filterLayer"}, {}]
			}]
		}]
	}],
	masterNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"masterLayer"}, {}]
			}]
		}]
	}],
	homeNavCall: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"homeLayer"}, {}]
			}]
		}]
	}],
	layoutBox1: ["wm.Layout", {"height":"100%","width":"100%","horizontalAlign":"center","verticalAlign":"top"}, {}, {
		panel6: ["wm.Panel", {"width":"900px","height":"100%","horizontalAlign":"left","verticalAlign":"top"}, {}, {
			panel14: ["wm.Panel", {"width":"966px","height":"30px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}],
			panel1: ["wm.Panel", {"_classes":{"domNode":["wm_BackgroundColor_White"]},"width":"100%","height":"96px","horizontalAlign":"left","verticalAlign":"bottom","layoutKind":"left-to-right"}, {}, {
				picture1: ["wm.Picture", {"height":"70px","width":"300px","source":"resources/images/explorer.jpg"}, {}, {
					binding: ["wm.Binding", {}, {}, {
						wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/explorer.jpg\""}, {}]
					}]
				}],
				panel15: ["wm.Panel", {"_classes":{"domNode":["wm_Attribution_bottomRight"]},"width":"100%","height":"100%","horizontalAlign":"left","verticalAlign":"top"}, {}]
			}],
			panel12: ["wm.Panel", {"_classes":{"domNode":["wm_BackgroundColor_LightBlue"]},"width":"100%","height":"30px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
				spacer2: ["wm.Spacer", {"width":"100%","height":"30px"}, {}],
				button1: ["wm.Button", {"caption":"Home","width":"96px","height":"30px"}, {"onclick":"homeNavCall"}]
			}],
			panel2: ["wm.Panel", {"_classes":{"domNode":["wm_BackgroundColor_White"]},"width":"100%","height":"100%","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
				panel3: ["wm.Panel", {"width":"120px","height":"100%","horizontalAlign":"left","verticalAlign":"top"}, {}, {
					label3: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_20px","wm_FontColor_White","wm_BackgroundColor_LightGray"]},"caption":"Menu","height":"32px","width":"100%"}, {}, {
						format: ["wm.DataFormatter", {}, {}]
					}],
					mainMenu: ["wm.DojoMenu", {"_classes":{"domNode":["wm_FontSizePx_14px"]},"structure":"{\"items\":[{\"label\":\"Basics\",\"children\":[{\"label\":\"Panels\"},{\"label\":\"Sizing\"},{\"label\":\"Layout\"},{\"label\":\"Showing\"},{\"label\":\"Disabled\"}]},{\"label\":\"Charts\",\"children\":[{\"label\":\"Pie\"},{\"label\":\"Bar\"}]},{\"label\":\"Data\",\"children\":[{\"label\":\"LiveForm\"},{\"label\":\"Related To Many\"},{\"label\":\"Related To One\"},{\"label\":\"Navigation\"}]},{\"label\":\"Editors\",\"children\":[{\"label\":\"General\"},{\"label\":\"Select\"},{\"label\":\"Validation\"}]},{\"label\":\"Grids\",\"children\":[{\"label\":\"Basic\"},{\"label\":\"Filtered\"},{\"label\":\"Master-Detail\"}]},{\"label\":\"Menus\"},{\"label\":\"Windows\"}]}","menu":"Basics>Panels,Sizing,Layout,Showing,Disabled\nCharts> Pie, Bar\nData>LiveForm,Related To Many, Related To One,Navigation\nEditors>General, Select, Validation\nGrids>Basic, Filtered, Master-Detail\nMenus\nWindows\n\n\n\n\n\n\n","eventList":[{"label":"Layout","onClick":"layoutNavCall"},{"label":"Editors","children":[{"label":"Date"},{"label":"Text"},{"label":"Select"}],"onClick":""},{"label":"Select","onClick":"selectNavCall"},{"label":"Charts","children":[{"label":"Pie"},{"label":"Bar"}],"onClick":undefined},{"label":"Pie","onClick":"pieNavCall"},{"label":"Bar","onClick":"barNavCall"},{"label":"Sizing","onClick":"sizingNavCall"},{"label":"Showing","onClick":"showingNavCall"},{"label":"Disabled","onClick":"disabledNavCall"},{"label":"Grids","children":[{"label":"Basic"},{"label":"Filtered"},{"label":"Master-Detail"}],"onClick":undefined},{"label":"Basic","onClick":"gridNavCall"},{"label":"Basic","onClick":"navigationCall7"},{"label":"Filtered","onClick":"filterNavCall"},{"label":"Master-Detail","onClick":"masterNavCall"},{"label":"Validation","onClick":"validNavCall"},{"label":"General","onClick":"editorNavCall"},{"label":"Panels","onClick":"panelNavCall"},{"label":"Windows","onClick":"popupNavCall"},{"label":"Menus","onClick":"menuNavCall"},{"label":"Basics","children":[{"label":"Panels"},{"label":"Sizing"},{"label":"Layout"},{"label":"Showing"},{"label":"Disabled"}],"onClick":undefined},{"label":"Data","onClick":""},{"label":"LiveForm","onClick":"dataNavCall"},{"label":"Navigation","onClick":"navLayerNavCall"},{"label":"Related To Many","onClick":"relatedNavCall"},{"label":"Related To One","onClick":"relToOneNavCall"}],"width":"100px","height":"100%","vertical":true}, {}]
				}],
				masterLayers: ["wm.Layers", {}, {}, {
					homeLayer: ["wm.Layer", {"caption":"Home","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						content1: ["wm.Content", {"height":"147px","margin":"10","content":"whatIsWaveMaker"}, {}],
						label2: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_20px","wm_FontColor_White","wm_BackgroundColor_LightGray"]},"caption":"Highlighted Examples (Click on Pictures)","height":"32px","width":"100%"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						panel4: ["wm.Panel", {"width":"100%","height":"184px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
							panel5: ["wm.Panel", {"width":"373px","height":"100%","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
								picture2: ["wm.Picture", {"height":"180px","width":"180px","source":"resources/images/piethumb.gif"}, {"onclick":"pieNavCall"}, {
									binding: ["wm.Binding", {}, {}, {
										wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/piethumb.gif\""}, {}]
									}]
								}],
								content2: ["wm.Content", {"height":"100%","margin":"10","content":"example1"}, {}]
							}],
							panel7: ["wm.Panel", {"width":"373px","height":"100%","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
								picture3: ["wm.Picture", {"height":"180px","width":"180px","source":"resources/images/panelthumb.gif"}, {"onclick":"panelNavCall"}, {
									binding: ["wm.Binding", {}, {}, {
										wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/panelthumb.gif\""}, {}]
									}]
								}],
								content3: ["wm.Content", {"height":"100%","margin":"10","content":"example2"}, {}]
							}]
						}],
						panel8: ["wm.Panel", {"width":"100%","height":"184px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
							panel9: ["wm.Panel", {"width":"373px","height":"100%","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
								picture4: ["wm.Picture", {"height":"180px","width":"180px","source":"resources/images/liveformthumb.gif"}, {"onclick":"dataNavCall"}, {
									binding: ["wm.Binding", {}, {}, {
										wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/liveformthumb.gif\""}, {}]
									}]
								}],
								content4: ["wm.Content", {"height":"100%","margin":"10","content":"example3"}, {}]
							}],
							panel10: ["wm.Panel", {"width":"373px","height":"100%","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
								picture5: ["wm.Picture", {"height":"180px","width":"180px","source":"resources/images/masterthumb.gif"}, {"onclick":"relatedNavCall"}, {
									binding: ["wm.Binding", {}, {}, {
										wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/masterthumb.gif\""}, {}]
									}]
								}],
								content5: ["wm.Content", {"height":"100%","margin":"10","content":"example4"}, {}]
							}]
						}]
					}],
					panelLayer: ["wm.Layer", {"caption":"Panel","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer13: ["wm.PageContainer", {"height":"100%","pageName":"PagePanels","deferLoad":true}, {}]
					}],
					sizingLayer: ["wm.Layer", {"caption":"Sizing","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer1: ["wm.PageContainer", {"height":"100%","pageName":"PageSize","deferLoad":true,"border":"0","borderColor":"#FFFFFF"}, {}]
					}],
					layoutLayer: ["wm.Layer", {"caption":"Layout","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer2: ["wm.PageContainer", {"height":"100%","pageName":"PageLayout","deferLoad":true}, {}]
					}],
					showingLayer: ["wm.Layer", {"caption":"Showing","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer3: ["wm.PageContainer", {"height":"100%","pageName":"PageVis","deferLoad":true}, {}]
					}],
					disabledLayer: ["wm.Layer", {"caption":"Disabled","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer4: ["wm.PageContainer", {"height":"100%","pageName":"PageDis","deferLoad":true}, {}]
					}],
					pieLayer: ["wm.Layer", {"caption":"Pie","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer5: ["wm.PageContainer", {"height":"100%","pageName":"PagePie","deferLoad":true}, {}]
					}],
					barLayer: ["wm.Layer", {"caption":"Bar","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer6: ["wm.PageContainer", {"height":"100%","pageName":"PageBar","deferLoad":true}, {}]
					}],
					gridLayer: ["wm.Layer", {"caption":"Grid","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer7: ["wm.PageContainer", {"height":"100%","pageName":"PageGrid","deferLoad":true}, {}]
					}],
					filterLayer: ["wm.Layer", {"caption":"Filter","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer8: ["wm.PageContainer", {"height":"100%","pageName":"PageFiltr","deferLoad":true}, {}]
					}],
					masterLayer: ["wm.Layer", {"caption":"Master","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer9: ["wm.PageContainer", {"height":"100%","pageName":"PageMaster","deferLoad":true}, {}]
					}],
					editorLayer: ["wm.Layer", {"caption":"Editor","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer10: ["wm.PageContainer", {"height":"100%","pageName":"PageEditors","deferLoad":true}, {}]
					}],
					selectLayer: ["wm.Layer", {"caption":"Select","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer11: ["wm.PageContainer", {"height":"100%","pageName":"PageSelect","deferLoad":true}, {}]
					}],
					validLayer: ["wm.Layer", {"caption":"Validation","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer12: ["wm.PageContainer", {"height":"100%","pageName":"PageValid","deferLoad":true}, {}]
					}],
					popupLayer: ["wm.Layer", {"caption":"Popup","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer14: ["wm.PageContainer", {"height":"100%","pageName":"PageWindows"}, {}]
					}],
					menuLayer: ["wm.Layer", {"caption":"Menu","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer15: ["wm.PageContainer", {"height":"100%","pageName":"PageMenu","deferLoad":true}, {}]
					}],
					dataLayer: ["wm.Layer", {"caption":"Data","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer16: ["wm.PageContainer", {"height":"100%","pageName":"PageData"}, {}]
					}],
					relatedLayer: ["wm.Layer", {"caption":"Related","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer17: ["wm.PageContainer", {"height":"100%","pageName":"PageRelated","deferLoad":true}, {}]
					}],
					navLayer: ["wm.Layer", {"caption":"Navigation","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer19: ["wm.PageContainer", {"height":"100%","pageName":"PageNav","deferLoad":true}, {}]
					}],
					relToOneLayer: ["wm.Layer", {"caption":"RelToOne","horizontalAlign":"left","verticalAlign":"top"}, {}, {
						pageContainer18: ["wm.PageContainer", {"height":"100%","pageName":"PageRelToOne","deferLoad":true}, {}]
					}]
				}]
			}]
		}]
	}]
}