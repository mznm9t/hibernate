dojo.declare("PagePanels", wm.Page, {
  start: function() {
    
  },
  // This function gets called by the onclick event for the borderButton widget  
  borderButtonClick: function(inSender) {
    // Change the "border" parameter for the panel to 0px so it does not display 
    this.panel2.setValue("border",0);  
    this.panel3.setValue("border",0); 
    this.panel4.setValue("border",0); 
    this.panel5.setValue("border",0);    
    this.panel6.setValue("border",0);          
  },
  // This function gets called by the onclick event for the borderButton widget  
  onButtonClick: function(inSender, inEvent) {
    try {
    // Change the "border" parameter for the panel to 5px so it does displays 
    this.panel2.setValue("border",5);  
    this.panel3.setValue("border",5); 
    this.panel4.setValue("border",5); 
    this.panel5.setValue("border",5);    
    this.panel6.setValue("border",5);            
    } catch(e) {
      console.error('ERROR IN onButtonClick: ' + e); 
    } 
  },
  _end: 0
});