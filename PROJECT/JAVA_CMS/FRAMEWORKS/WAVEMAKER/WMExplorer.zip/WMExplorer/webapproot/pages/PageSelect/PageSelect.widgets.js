PageSelect.widgets = {
	customerLiveVar: ["wm.LiveVariable", {"liveSource":"com.data.Customer"}, {}],
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"500px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px"}, {}, {
						content2: ["wm.Content", {"_classes":{"domNode":["wm_Padding_10px"]},"height":"100%","width":"100px","margin":"10","content":"selectText"}, {}]
					}],
					spacer12: ["wm.Spacer", {"width":"20px"}, {}],
					panelWidgetFlex: ["wm.Panel", {"_classes":{"domNode":["wm_Border_Size3px","wm_Border_ColorBlack"]},"width":"260px","height":"100%","border":"5","borderColor":"#999999"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						label3: ["wm.Label", {"caption":"Select editor with static choices","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						selectEditor1: ["wm.SelectEditor", {"caption":"Select state","captionSize":"60%"}, {"onchange":"selectEditor1Change"}, {
							editor: ["wm._SelectEditor", {"options":"AK,AL,AR,AZ,CA,CO,CT,DE,FL,GA,HI,IA,ID,IL,IN,KS,KY,LA,MA,MD,ME,MI,MN,MO,MS,MT,NC,ND,NE,NH,NJ,NM,NV,NY,OH,OK,OR,PA,RI,SC,SD,TN,TX,UT,VA,VT,WA,WI,WV,WY","displayField":"name","dataField":"dataValue"}, {}, {
								optionsVar: ["wm.Variable", {"type":"EntryData"}, {}]
							}]
						}],
						label4: ["wm.Label", {"caption":"Select editor with database choices","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						selectEditor2: ["wm.SelectEditor", {"caption":"Select customer","captionSize":"60%"}, {"onchange":"selectEditor2Change"}, {
							editor: ["wm._SelectEditor", {"displayField":"name","dataField":"custid"}, {}, {
								binding: ["wm.Binding", {}, {}, {
									wire: ["wm.Wire", {"targetProperty":"dataSet","source":"customerLiveVar","expression":undefined}, {}]
								}]
							}]
						}],
						spacer1: ["wm.Spacer", {"height":"20px","width":"96px"}, {}],
						label2: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"You Entered","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						label5: ["wm.Label", {"height":"33px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						label6: ["wm.Label", {"height":"33px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}]
					}],
					spacer10: ["wm.Spacer", {"width":"20px"}, {}],
					pictureWidgetFlex: ["wm.Picture", {"height":"100%","width":"200px","source":"resources/images/select.gif"}, {}, {
						binding: ["wm.Binding", {}, {}, {
							wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/select.gif\""}, {}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"sizingJSCode"}, {}]
				}]
			}]
		}]
	}]
}