dojo.declare("PageVis", wm.Page, {
  start: function() {
    
  },
  // This function gets called by the onclick event for the buttonLeft widget  
  buttonShowingClick: function(inSender) {
    // Change the "layoutKind" parameter for the panel to "left-to-right" 
    this.label2.show();  
    this.label5.setCaption("The widget is showing");
  },
  // This function gets called by the onclick event for the buttonLeft widget  
  buttonNotShowingClick: function(inSender) {
    // Change the "layoutKind" parameter for the panel to "left-to-right" 
    this.label2.hide();  
    this.label5.setCaption("The widget is now hidden");
  },
  _end: 0
});