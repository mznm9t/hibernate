dojo.declare("PageGrid", wm.Page, {
  start: function() {
 
  },
  // This function gets called by the onclick event for the buttonDate widget  
  buttonDateClick: function(inSender, inEvent) {
    try {
        // Set the grid to sort column 2, orderdate - col numbering starts w 0
        this.dataGrid1.dijit.setSortIndex(2);
     this.dataGrid1.setValue("dataValue",false);      
    } catch(e) {
      console.error('ERROR IN buttonDateClick: ' + e); 
    } 
  },
  // This function gets called by the onclick event for the buttonState widget  
  buttonStateClick: function(inSender, inEvent) {
    try {
        // Set the grid to sort column 1, state - col numbering starts w 0
        this.dataGrid1.dijit.setSortIndex(1);
     this.dataGrid1.setValue("dataValue",false);       
    } catch(e) {
      console.error('ERROR IN buttonStateClick: ' + e); 
    } 
  },
  _end: 0
});