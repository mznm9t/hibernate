dojo.declare("Main", wm.Page, {
  start: function() {
    
  }

});