PageGrid.widgets = {
	custPurchasesSvcVar: ["wm.ServiceVariable", {"service":"gurudb","operation":"purchaseByCustomer","startUpdate":true}, {}, {
		input: ["wm.ServiceInput", {"type":"purchaseByCustomerInputs"}, {}]
	}],
	updateSvcVar: ["wm.ServiceVariable", {"service":"gurudb","operation":"updatePurchase"}, {}, {
		input: ["wm.ServiceInput", {"type":"updatePurchaseInputs"}, {}]
	}],
	doEventsVar: ["wm.Variable", {"type":"BooleanData"}, {}],
	purchaseLiveVariable1: ["wm.LiveVariable", {"liveSource":"app.purchaseLiveView1"}, {}],
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"600px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px","height":"100%"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						panel1: ["wm.Panel", {"width":"100%","height":"63px","horizontalAlign":"center","verticalAlign":"top"}, {}, {
							buttonState: ["wm.Button", {"caption":"Sort By State","width":"140px","height":"25px"}, {"onclick":"buttonStateClick"}],
							buttonDate: ["wm.Button", {"caption":"Sort By Date","width":"140px","height":"25px"}, {"onclick":"buttonDateClick"}]
						}],
						layoutContent1: ["wm.Content", {"height":"202px","margin":"10","content":"gridText"}, {}],
						picture1: ["wm.Picture", {"height":"100%","width":"100%","source":"resources/images/grid.gif"}, {}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/grid.gif\""}, {}]
							}]
						}]
					}],
					spacer12: ["wm.Spacer", {"width":"30px"}, {}],
					panel2: ["wm.Panel", {"width":"100%","height":"100%","horizontalAlign":"left","verticalAlign":"top","border":"5","borderColor":"#999999"}, {}, {
						dataGrid1: ["wm.DataGrid", {"border":"5","borderColor":"#666666"}, {}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"targetProperty":"dataSet","source":"purchaseLiveVariable1","expression":undefined}, {}]
							}],
							orderdate1: ["wm.DataGridColumn", {"field":"orderdate","index":2,"display":"Date","caption":"Orderdate","autoSize":undefined}, {}, {
								format: ["wm.DateFormatter", {}, {}]
							}],
							ordervalue1: ["wm.DataGridColumn", {"field":"ordervalue","index":3,"display":"Number","caption":"Ordervalue","autoSize":undefined,"columnWidth":"77px"}, {}, {
								format: ["wm.NumberFormatter", {}, {}]
							}],
							customerName1: ["wm.DataGridColumn", {"field":"customer.name","caption":"Customer Name","autoSize":undefined,"columnWidth":"149px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							customerState1: ["wm.DataGridColumn", {"field":"customer.state","index":1,"caption":"State","autoSize":undefined,"columnWidth":"70px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"gridJSCode"}, {}]
				}]
			}]
		}]
	}]
}