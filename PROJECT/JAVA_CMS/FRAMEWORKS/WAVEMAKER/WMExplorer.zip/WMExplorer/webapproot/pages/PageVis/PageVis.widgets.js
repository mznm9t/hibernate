PageVis.widgets = {
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"500px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						panel1: ["wm.Panel", {"width":"100%","height":"63px","horizontalAlign":"center","verticalAlign":"top"}, {}, {
							buttonNotShowing: ["wm.Button", {"caption":"Layout = not showing","width":"140px","height":"25px"}, {"onclick":"buttonNotShowingClick"}],
							buttonShowing: ["wm.Button", {"caption":"Layout = showing","width":"140px","height":"25px"}, {"onclick":"buttonShowingClick"}]
						}],
						layoutContent1: ["wm.Content", {"margin":"10","content":"showingText"}, {}]
					}],
					spacer12: ["wm.Spacer", {"width":"30px"}, {}],
					panel2: ["wm.Panel", {"width":"100%","height":"200px","horizontalAlign":"left","verticalAlign":"top","border":"5","borderColor":"#999999","scrollX":true,"scrollY":true}, {}, {
						label5: ["wm.Label", {"caption":"The widget is showing","height":"70px","width":"100px","singleLine":false}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						label2: ["wm.Label", {"_classes":{"domNode":["wm_BackgroundColor_Green","wm_FontColor_White"]},"caption":"Widget 1","height":"100px","width":"100px","margin":"4"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}]
					}],
					spacer10: ["wm.Spacer", {"width":"30px"}, {}],
					pictureWidgetFlex: ["wm.Picture", {"height":"100%","width":"200px","source":"resources/images/showing.gif"}, {}, {
						binding: ["wm.Binding", {}, {}, {
							wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/showing.gif\""}, {}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"visJSCode"}, {}]
				}]
			}]
		}]
	}]
}