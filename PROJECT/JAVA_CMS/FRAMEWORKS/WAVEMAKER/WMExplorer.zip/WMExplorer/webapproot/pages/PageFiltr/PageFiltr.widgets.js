PageFiltr.widgets = {
	custPurchasesSvcVar: ["wm.ServiceVariable", {"service":"gurudb","operation":"purchaseByCustomer","startUpdate":true}, {}, {
		input: ["wm.ServiceInput", {"type":"purchaseByCustomerInputs"}, {}]
	}],
	updateSvcVar: ["wm.ServiceVariable", {"service":"gurudb","operation":"updatePurchase"}, {}, {
		input: ["wm.ServiceInput", {"type":"updatePurchaseInputs"}, {}]
	}],
	doEventsVar: ["wm.Variable", {"type":"BooleanData"}, {}],
	purchaseLiveVariable1: ["wm.LiveVariable", {"liveSource":"app.purchaseLiveView1"}, {}],
	purchaseVar: ["wm.Variable", {"type":"com.data.Purchase"}, {}],
	purchaseLiveVarFilter: ["wm.LiveVariable", {"liveSource":"app.purchaseLiveView1"}, {}, {
		binding: ["wm.Binding", {}, {}, {
			wire: ["wm.Wire", {"targetProperty":"filter.customer.state","source":"stateSelectEditor.dataValue"}, {}]
		}]
	}],
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"600px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px","height":"100%"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						panel1: ["wm.Panel", {"width":"100%","height":"64px","horizontalAlign":"center","verticalAlign":"top"}, {}, {
							stateSelectEditor: ["wm.SelectEditor", {"caption":"Filter by State","captionSize":"80%","width":"100%"}, {}, {
								editor: ["wm._SelectEditor", {"options":"CA, MA, NY, OR, TX","displayField":"name","dataField":"dataValue"}, {}, {
									optionsVar: ["wm.Variable", {"type":"EntryData"}, {}]
								}]
							}],
							buttonClear: ["wm.Button", {"caption":"Clear Filter","width":"140px","height":"25px"}, {"onclick":"buttonClearClick"}]
						}],
						layoutContent1: ["wm.Content", {"height":"202px","margin":"10","content":"filterText"}, {}],
						picture1: ["wm.Picture", {"height":"100%","width":"100%","source":"resources/images/filter.gif"}, {}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/filter.gif\""}, {}]
							}]
						}]
					}],
					spacer12: ["wm.Spacer", {"width":"30px"}, {}],
					panel2: ["wm.Panel", {"width":"100%","height":"100%","horizontalAlign":"left","verticalAlign":"top","border":"5","borderColor":"#999999"}, {}, {
						dataGrid1: ["wm.DataGrid", {"border":"5","borderColor":"#666666"}, {}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"targetProperty":"dataSet","source":"purchaseLiveVarFilter","expression":undefined}, {}]
							}],
							orderdate1: ["wm.DataGridColumn", {"field":"orderdate","index":2,"caption":"Orderdate","display":"Date","autoSize":undefined}, {}, {
								format: ["wm.DateFormatter", {}, {}]
							}],
							ordervalue1: ["wm.DataGridColumn", {"field":"ordervalue","index":3,"caption":"Ordervalue","display":"Number","autoSize":undefined,"columnWidth":"77px"}, {}, {
								format: ["wm.NumberFormatter", {}, {}]
							}],
							customerName1: ["wm.DataGridColumn", {"field":"customer.name","caption":"Customer Name","autoSize":undefined,"columnWidth":"149px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							customerState1: ["wm.DataGridColumn", {"field":"customer.state","index":1,"caption":"State","autoSize":undefined,"columnWidth":"70px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"filterJSCode"}, {}]
				}]
			}]
		}]
	}]
}