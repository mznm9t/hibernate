dojo.declare("PageSize", wm.Page, {
  start: function() {
    
  },
  // This function gets called by the onclick event for the 100% button  
  buttonFlexClick: function(inSender) {
    // Change the "height" parameter for the label to "100%" of available space
    this.labelFlex.setValue("height","100%");  
    this.labelWidgetFlex.setValue("caption","Widget in panel now has width = 100%");
  },
  // This function gets called by the onclick event for the 50px  button
  buttonPxClick: function(inSender) {
    // Change the "height" parameter for the label to "50px"
    this.labelFlex.setValue("height","50px");    
    this.labelWidgetFlex.setValue("caption","Widget in panel is now 50 px tall");
  },
  _end: 0
});