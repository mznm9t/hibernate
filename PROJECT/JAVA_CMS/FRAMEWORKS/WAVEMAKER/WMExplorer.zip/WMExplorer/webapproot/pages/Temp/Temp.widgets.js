Temp.widgets = {
	navigationCall1: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"layer2"}, {}]
			}]
		}]
	}],
	navigationCall2: ["wm.NavigationCall", {}, {}, {
		input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
			binding: ["wm.Binding", {}, {}, {
				wire: ["wm.Wire", {"targetProperty":"layer","source":"layer3"}, {}]
			}]
		}]
	}],
	layoutBox1: ["wm.Layout", {"height":"100%","width":"100%","horizontalAlign":"left","verticalAlign":"top"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Tab navigation","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
				panel1: ["wm.Panel", {"height":"100%","width":"179px","verticalAlign":"top","horizontalAlign":"left"}, {}, {
					button1: ["wm.Button", {"height":"32px","width":"96px","caption":"Goto Layer1"}, {"onclick":"navigationCall1"}],
					button2: ["wm.Button", {"height":"32px","width":"96px","caption":"Goto Layer2"}, {"onclick":"navigationCall2"}],
					button3: ["wm.Button", {"height":"32px","width":"96px","caption":"Get Selected Layer"}, {"onclick":"button3Click"}],
					label1: ["wm.Label", {"height":"48px","width":"100%","caption":"label1"}, {}, {
						format: ["wm.DataFormatter", {}, {}]
					}]
				}],
				panel2: ["wm.Panel", {"height":"100%","width":"199px","verticalAlign":"top","horizontalAlign":"left"}, {}, {
					tabLayers2: ["wm.TabLayers", {}, {}, {
						layer2: ["wm.Layer", {"caption":"layer2","horizontalAlign":"left","verticalAlign":"top"}, {}],
						layer3: ["wm.Layer", {"caption":"layer3","horizontalAlign":"left","verticalAlign":"top"}, {}],
						layer4: ["wm.Layer", {"caption":"layer4","horizontalAlign":"left","verticalAlign":"top"}, {}]
					}]
				}]
			}],
			layer5: ["wm.Layer", {"caption":"Popup Window","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
				panel3: ["wm.Panel", {"height":"100%","width":"172px","verticalAlign":"top","horizontalAlign":"left"}, {}, {
					windowButton: ["wm.Button", {"height":"48px","width":"96px","caption":"Popup window"}, {"onclick":"windowButtonClick"}],
					alertButton: ["wm.Button", {"height":"48px","width":"96px","caption":"Popup Alert"}, {"onclick":"alertButtonClick"}]
				}]
			}],
			layer7: ["wm.Layer", {"caption":"Menu","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
				panel4: ["wm.Panel", {"height":"100%","width":"171px","verticalAlign":"top","horizontalAlign":"left"}, {}, {
					verticalButton: ["wm.Button", {"height":"32px","width":"96px","caption":"Vertical Menu"}, {"onclick":"verticalButtonClick"}],
					horizButton: ["wm.Button", {"height":"32px","width":"96px","caption":"Horizontal menu"}, {"onclick":"horizButtonClick"}],
					label2: ["wm.Label", {"height":"48px","width":"96px","caption":"label2"}, {}, {
						format: ["wm.DataFormatter", {}, {}]
					}]
				}],
				panel5: ["wm.Panel", {"height":"100%","width":"198px","layoutKind":"left-to-right","verticalAlign":"top","horizontalAlign":"left"}, {}, {
					dojoMenu1: ["wm.DojoMenu", {"structure":"{\"items\":[{\"label\":\"File\",\"children\":[{\"label\":\"This\"},{\"label\":\"That\"},{\"label\":\"Other\"}]},{\"label\":\"Jazz\",\"children\":[{\"label\":\"Bebop\"},{\"label\":\"Swing\"},{\"label\":\"Free\"}]}]}","menu":"File>This,That,Other\nJazz>Bebop,Swing,Free\n\t","eventList":[{"label":"File","children":[{"label":"This"},{"label":"That"},{"label":"Other"}],"onClick":undefined},{"label":"This","onClick":"onDojoMenuThisClick"},{"label":"That","onClick":undefined},{"label":"Other","onClick":undefined},{"label":"Jazz","children":[{"label":"Bebop"},{"label":"Swing"},{"label":"Free"}],"onClick":undefined},{"label":"Bebop","onClick":undefined},{"label":"Swing","onClick":undefined},{"label":"Free","onClick":undefined}]}, {}]
				}]
			}],
			layer6: ["wm.Layer", {"caption":"Progress Bar","horizontalAlign":"left","verticalAlign":"top"}, {}, {
				progressBar1: ["wm.dijit.ProgressBar", {"height":"32px","width":"360px"}, {}],
				button4: ["wm.Button", {"height":"48px","width":"96px","caption":"Increase progress"}, {"onclick":"button4Click"}]
			}],
			layer8: ["wm.Layer", {"caption":"Twitter","horizontalAlign":"left","verticalAlign":"top"}, {}, {
				label3: ["wm.Label", {"height":"48px","width":"96px","caption":"label3"}, {}, {
					format: ["wm.DataFormatter", {}, {}]
				}],
				button5: ["wm.Button", {"height":"48px","width":"96px","caption":"Twitter Wavemaker"}, {"onclick":"button5Click"}],
				feedList1: ["wm.FeedList", {"url":"http://twitter.com/#search?q=wavemaker"}, {}, {
					getFeedServiceVariable: ["wm.ServiceVariable", {"service":"FeedService","operation":"getFeed"}, {}, {
						input: ["wm.ServiceInput", {"type":"getFeedInputs"}, {}]
					}]
				}]
			}]
		}]
	}]
}