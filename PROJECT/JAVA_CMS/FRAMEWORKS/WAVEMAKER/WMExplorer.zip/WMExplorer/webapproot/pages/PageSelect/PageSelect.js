dojo.declare("PageSelect", wm.Page, {
  start: function() {
    
  },
  // This function is called when the editor1 widget changes
  selectEditor1Change: function(inSender, inDisplayValue, inDataValue) {
    try {
       // Display value of selected item
       this.label5.setCaption('Selected state = '+this.selectEditor1.getDataValue());      
    } catch(e) {
      console.error('ERROR IN selectEditor1Change: ' + e); 
    } 
  },
  // This function is called when the editor1 widget changes
  selectEditor2Change: function(inSender, inDisplayValue, inDataValue) {
    try {
       // Display value of selected item
       this.label6.setCaption('Selected customer = '+this.selectEditor2.getDisplayValue()+' id = '+this.selectEditor2.getDataValue());                           
    } catch(e) {
      console.error('ERROR IN selectEditor2Change: ' + e); 
    } 
  },
  _end: 0
});