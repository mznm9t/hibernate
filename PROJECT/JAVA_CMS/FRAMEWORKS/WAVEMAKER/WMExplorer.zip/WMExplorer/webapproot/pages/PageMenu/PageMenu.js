dojo.declare("PageMenu", wm.Page, {
  start: function() {
    
  },
  // This function gets called by the onclick event for the verticalButton widget  
  verticalButtonClick: function(inSender, inEvent) {
    try {    
       // Set the dojo menu widget to display in vertical mode
       this.exampleMenu.setValue('vertical',true);      
    } catch(e) {
      console.error('ERROR IN verticalButtonClick: ' + e); 
    } 
  },
  // This function gets called by the onclick event for the horizButton widget
  horizButtonClick: function(inSender, inEvent) {
    try {
       // Set the dojo menu widget to display in horizontal mode
       this.exampleMenu.setValue('vertical',false);            
    } catch(e) {
      console.error('ERROR IN horizButtonClick: ' + e); 
    } 
  },

  onDojoMenuFileClick: function(inSender /*,args*/) {
    try {
        alert('Menu option selected!');
      
    } catch(e) {
      console.error('ERROR IN onDojoMenuFileClick: ' + e); 
    } 
  },
  onDojoMenuThisClick: function(inSender /*,args*/) {
    try {
     
      
    } catch(e) {
      console.error('ERROR IN onDojoMenuThisClick: ' + e); 
    } 
  },
  onDojoMenuHelpClick: function(inSender /*,args*/) {
    try {
     
      
    } catch(e) {
      console.error('ERROR IN onDojoMenuHelpClick: ' + e); 
    } 
  },
  _end: 0
});