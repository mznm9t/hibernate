dojo.declare("PagePie", wm.Page, {
  start: function() {
    
  },
  // This function gets called by the onclick event for the buttonBar widget  
  buttonBarClick: function(inSender, inEvent) {
    try {
       // Set the dojo chart to display a column or bar chart
       this.dojoChart1.setValue('chartType','Columns');      
    } catch(e) {
      console.error('ERROR IN buttonBarClick: ' + e); 
    } 
  },
  // This function gets called by the onclick event for the buttonPie widget  
  buttonPieClick: function(inSender, inEvent) {
    try {
       // Set the dojo chart to display a column or bar chart
       this.dojoChart1.setValue('chartType','Pie');           
    } catch(e) {
      console.error('ERROR IN buttonPieClick: ' + e); 
    } 
  },
  _end: 0
});