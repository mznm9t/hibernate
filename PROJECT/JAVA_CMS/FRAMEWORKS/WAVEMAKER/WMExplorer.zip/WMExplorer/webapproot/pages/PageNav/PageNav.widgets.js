PageNav.widgets = {
	custPurchasesSvcVar: ["wm.ServiceVariable", {"service":"gurudb","operation":"purchaseByCustomer","startUpdate":true}, {}, {
		input: ["wm.ServiceInput", {"type":"purchaseByCustomerInputs"}, {}]
	}],
	updateSvcVar: ["wm.ServiceVariable", {"service":"gurudb","operation":"updatePurchase"}, {}, {
		input: ["wm.ServiceInput", {"type":"updatePurchaseInputs"}, {}]
	}],
	doEventsVar: ["wm.Variable", {"type":"BooleanData"}, {}],
	purchaseLiveVariable1: ["wm.LiveVariable", {"liveSource":"app.purchaseLiveView1"}, {}, {
		binding: ["wm.Binding", {}, {}, {
			wire: ["wm.Wire", {"targetProperty":"filter.customer.state","source":"selectEditor1.dataValue"}, {}]
		}]
	}],
	purchaseVar: ["wm.Variable", {"type":"com.data.Purchase"}, {}],
	customerLiveVariable1: ["wm.LiveVariable", {"liveSource":"app.customerLiveView1"}, {}],
	customerLiveVariable2: ["wm.LiveVariable", {"liveSource":"app.customerLiveView2"}, {}],
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"600px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px","height":"100%"}, {}, {
						layoutContent1: ["wm.Content", {"height":"257px","margin":"10","content":"dataNavText"}, {}],
						picture1: ["wm.Picture", {"height":"100%","width":"100%","source":"resources/images/navigator.gif"}, {}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/navigator.gif\""}, {}]
							}]
						}]
					}],
					spacer12: ["wm.Spacer", {"width":"30px"}, {}],
					panel2: ["wm.Panel", {"width":"100%","height":"100%","border":"5","horizontalAlign":"left","verticalAlign":"top","borderColor":"#999999"}, {}, {
						liveForm1: ["wm.LiveForm", {"verticalAlign":"top","horizontalAlign":"left","readonly":true,"fitToContent":true,"height":"148px"}, {}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"targetProperty":"dataSet","source":"customerLiveVariable1","expression":undefined}, {}]
							}],
							label2: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"100%"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							custidEditor1: ["wm.Editor", {"caption":"Custid","display":"Number","readonly":true,"formField":"custid","width":"100%","height":"26px"}, {}, {
								editor: ["wm._NumberEditor", {"required":true}, {}]
							}],
							nameEditor1: ["wm.Editor", {"caption":"Name","readonly":true,"formField":"name","width":"100%","height":"26px"}, {}, {
								editor: ["wm._TextEditor", {}, {}]
							}],
							stateEditor1: ["wm.Editor", {"caption":"State","readonly":true,"formField":"state","width":"100%","height":"26px"}, {}, {
								editor: ["wm._TextEditor", {}, {}]
							}],
							editPanel1: ["wm.EditPanel", {"liveForm":"liveForm1","savePanel":"savePanel1","operationPanel":"operationPanel1","showing":false}, {}, {
								savePanel1: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right","horizontalAlign":"right","showing":false}, {}, {
									saveButton1: ["wm.Button", {"caption":"Save","width":"70px","height":"100%"}, {"onclick":"editPanel1.saveData"}, {
										binding: ["wm.Binding", {}, {}, {
											wire: ["wm.Wire", {"targetProperty":"disabled","source":"editPanel1.formInvalid","expression":undefined}, {}]
										}]
									}],
									cancelButton1: ["wm.Button", {"caption":"Cancel","width":"70px","height":"100%"}, {"onclick":"editPanel1.cancelEdit"}]
								}],
								operationPanel1: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right","horizontalAlign":"right"}, {}, {
									newButton1: ["wm.Button", {"caption":"New","width":"70px","height":"100%"}, {"onclick":"editPanel1.beginDataInsert"}],
									updateButton1: ["wm.Button", {"caption":"Update","width":"70px","height":"100%"}, {"onclick":"editPanel1.beginDataUpdate"}, {
										binding: ["wm.Binding", {}, {}, {
											wire: ["wm.Wire", {"targetProperty":"disabled","source":"editPanel1.formUneditable","expression":undefined}, {}]
										}]
									}],
									deleteButton1: ["wm.Button", {"caption":"Delete","width":"70px","height":"100%"}, {"onclick":"editPanel1.deleteData"}, {
										binding: ["wm.Binding", {}, {}, {
											wire: ["wm.Wire", {"targetProperty":"disabled","source":"editPanel1.formUneditable","expression":undefined}, {}]
										}]
									}]
								}]
							}],
							dataNavigator1: ["wm.DataNavigator", {"width":"100%"}, {}, {
								binding: ["wm.Binding", {}, {}, {
									wire: ["wm.Wire", {"targetProperty":"liveSource","source":"customerLiveVariable1","expression":undefined}, {}]
								}]
							}]
						}],
						label1: ["wm.Label", {"caption":"Use the navigator to go to the first or last customer, move sequentially through the list of customers, or go to a particular customer by row number","height":"99px","width":"100%"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"dataNavJSCode"}, {}]
				}]
			}]
		}]
	}]
}