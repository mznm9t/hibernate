PageEditors.widgets = {
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"500px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px"}, {}, {
						content2: ["wm.Content", {"_classes":{"domNode":["wm_Padding_10px"]},"height":"100%","margin":"10","content":"editorText","width":"100px"}, {}]
					}],
					spacer12: ["wm.Spacer", {"width":"30px"}, {}],
					panelWidgetFlex: ["wm.Panel", {"_classes":{"domNode":["wm_Border_Size3px","wm_Border_ColorBlack"]},"width":"300px","height":"100%","border":"5","borderColor":"#999999"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						checkBoxEditor1: ["wm.CheckBoxEditor", {"caption":"checkBox Editor"}, {"onchange":"checkBoxEditor1Change"}, {
							editor: ["wm._CheckBoxEditor", {}, {}]
						}],
						currencyEditor1: ["wm.CurrencyEditor", {"caption":"currency Editor"}, {"onchange":"currencyEditor1Change"}, {
							editor: ["wm._CurrencyEditor", {}, {}]
						}],
						dateEditor1: ["wm.DateEditor", {"caption":"date Editor"}, {"onchange":"dateEditor1Change"}, {
							editor: ["wm._DateEditor", {}, {}]
						}],
						numberEditor1: ["wm.NumberEditor", {"caption":"number Editor"}, {"onchange":"numberEditor1Change"}, {
							editor: ["wm._NumberEditor", {}, {}]
						}],
						radioButtonEditor1: ["wm.RadioButtonEditor", {"caption":"Rock is my thing","displayValue":"rock"}, {"onchange":"onRadioButtonEditorChange"}, {
							editor: ["wm._RadioButtonEditor", {"radioGroup":"rock","startChecked":true}, {}]
						}],
						radioButtonEditor2: ["wm.RadioButtonEditor", {"caption":"I prefer Jazz","displayValue":"jazz"}, {"onchange":"onRadioButtonEditorChange"}, {
							editor: ["wm._RadioButtonEditor", {"radioGroup":"rock"}, {}]
						}],
						textEditor1: ["wm.TextEditor", {"caption":"text Editor","height":"26px","singleLine":false}, {"onchange":"textEditor1Change"}, {
							editor: ["wm._TextEditor", {}, {}]
						}],
						sliderEditor1: ["wm.SliderEditor", {"caption":"sliderEditor1"}, {"onchange":"sliderEditor1Change"}, {
							editor: ["wm._SliderEditor", {}, {}]
						}],
						label2: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"You Entered","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						panel1: ["wm.Panel", {"width":"100%","height":"28px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
							label3: ["wm.Label", {"caption":"Checkbox = ","height":"28px","width":"96px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							checkBoxLabel: ["wm.Label", {"height":"28px","width":"96px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}]
						}],
						panel2: ["wm.Panel", {"width":"100%","height":"28px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
							label4: ["wm.Label", {"caption":"Currency = ","height":"28px","width":"96px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							currencyLabel: ["wm.Label", {"height":"28px","width":"96px","display":"Currency"}, {}, {
								format: ["wm.CurrencyFormatter", {"digits":2}, {}]
							}]
						}],
						panel3: ["wm.Panel", {"width":"100%","height":"28px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
							label5: ["wm.Label", {"caption":"Date = ","height":"28px","width":"96px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							dateLabel: ["wm.Label", {"height":"28px","width":"96px","display":"Date"}, {}, {
								format: ["wm.DateFormatter", {}, {}]
							}]
						}],
						panel4: ["wm.Panel", {"width":"100%","height":"28px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
							label6: ["wm.Label", {"caption":"Number = ","height":"28px","width":"96px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							numberLabel: ["wm.Label", {"height":"28px","width":"96px","display":"Number"}, {}, {
								format: ["wm.NumberFormatter", {}, {}]
							}]
						}],
						panel5: ["wm.Panel", {"width":"100%","height":"28px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
							label7: ["wm.Label", {"caption":"Number = ","height":"28px","width":"96px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							numberLabel1: ["wm.Label", {"height":"28px","width":"96px","display":"Number"}, {}, {
								format: ["wm.NumberFormatter", {}, {}]
							}]
						}],
						panel6: ["wm.Panel", {"width":"100%","height":"28px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
							label8: ["wm.Label", {"caption":"Radio button = ","height":"28px","width":"96px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							radioButtonLabel: ["wm.Label", {"height":"28px","width":"103px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}]
						}],
						panel7: ["wm.Panel", {"width":"100%","height":"28px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
							label9: ["wm.Label", {"caption":"Text = ","height":"28px","width":"96px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							textLabel: ["wm.Label", {"height":"28px","width":"100%"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}]
						}],
						panel8: ["wm.Panel", {"width":"100%","height":"28px","horizontalAlign":"left","verticalAlign":"top","layoutKind":"left-to-right"}, {}, {
							label10: ["wm.Label", {"caption":"Slider = ","height":"28px","width":"96px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							sliderLabel: ["wm.Label", {"height":"28px","width":"100%","display":"Number"}, {}, {
								format: ["wm.NumberFormatter", {"digits":2}, {}]
							}]
						}]
					}],
					spacer10: ["wm.Spacer", {"width":"30px"}, {}],
					pictureWidgetFlex: ["wm.Picture", {"height":"100%","width":"200px","source":"resources/images/editors.gif"}, {}, {
						binding: ["wm.Binding", {}, {}, {
							wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/editors.gif\""}, {}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"sizingJSCode"}, {}]
				}]
			}]
		}]
	}]
}