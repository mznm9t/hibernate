PageValid.widgets = {
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"500px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px"}, {}, {
						content2: ["wm.Content", {"_classes":{"domNode":["wm_Padding_10px"]},"height":"100%","width":"100px","margin":"10","content":"validText"}, {}]
					}],
					spacer12: ["wm.Spacer", {"width":"30px"}, {}],
					panelWidgetFlex: ["wm.Panel", {"_classes":{"domNode":["wm_Border_Size3px","wm_Border_ColorBlack"]},"width":"300px","height":"100%","border":"5","borderColor":"#999999"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						label7: ["wm.Label", {"caption":"Validation with built in editor - can only enter numbers","height":"28px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						currencyEditor1: ["wm.CurrencyEditor", {"caption":"currency Editor"}, {"onchange":"currencyEditor1Change"}, {
							editor: ["wm._CurrencyEditor", {}, {}]
						}],
						label8: ["wm.Label", {"caption":"Validation with regex - checks for email address","height":"28px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						textEditor1: ["wm.TextEditor", {"caption":"Email address"}, {}, {
							editor: ["wm._TextEditor", {"promptMessage":"Enter valid email address","invalidMessage":"Not a valid email address","regExp":"^[a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$"}, {}]
						}],
						label9: ["wm.Label", {"caption":"Validation with input mask - only allows digits","height":"28px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						textEditor2: ["wm.TextEditor", {"caption":"Numbers only"}, {"onchange":"textEditor2Change"}, {
							editor: ["wm._TextEditor", {}, {}]
						}]
					}],
					spacer10: ["wm.Spacer", {"width":"30px"}, {}],
					pictureWidgetFlex: ["wm.Picture", {"height":"100%","width":"200px","source":"resources/images/editors.gif"}, {}, {
						binding: ["wm.Binding", {}, {}, {
							wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/editors.gif\""}, {}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"validJSCode"}, {}]
				}]
			}]
		}]
	}]
}