PageSize.widgets = {
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"500px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						panel1: ["wm.Panel", {"width":"100%","height":"63px","horizontalAlign":"center","verticalAlign":"top"}, {}, {
							buttonFlex: ["wm.Button", {"caption":"Height = 100%","width":"100px","height":"25px"}, {"onclick":"buttonFlexClick"}],
							buttonPx: ["wm.Button", {"caption":"Height = 50 px","width":"100px","height":"25px"}, {"onclick":"buttonPxClick"}]
						}],
						content2: ["wm.Content", {"_classes":{"domNode":["wm_Padding_10px"]},"height":"100%","width":"100px","content":"sizingText"}, {}]
					}],
					spacer12: ["wm.Spacer", {"width":"30px"}, {}],
					panelWidgetFlex: ["wm.Panel", {"_classes":{"domNode":["wm_Border_Size3px","wm_Border_ColorBlack"]},"width":"200px","height":"100%","border":"5","borderColor":"#999999"}, {}, {
						labelWidgetFlex: ["wm.Label", {"_classes":{"domNode":["wm_FontSize_120percent","wm_FontColor_Graphite","wm_Padding_4px","wm_Border_Size1px","wm_Border_StyleSolid","wm_Border_ColorBlack"]},"caption":"Widgets in panel is 50px tall","height":"44px","width":"70px","singleLine":false}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						labelFlex: ["wm.Label", {"_classes":{"domNode":["wm_FontSize_150percent","wm_TextAlign_Center","wm_Padding_16px","wm_BackgroundColor_Blue","wm_FontColor_White"]},"caption":"I'm A Widget","height":"50px","width":"50px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}]
					}],
					spacer10: ["wm.Spacer", {"width":"30px"}, {}],
					pictureWidgetFlex: ["wm.Picture", {"height":"100%","width":"200px","source":"resources/images/sizing.gif"}, {}, {
						binding: ["wm.Binding", {}, {}, {
							wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/sizing.gif\""}, {}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"sizingJSCode"}, {}]
				}]
			}]
		}]
	}]
}