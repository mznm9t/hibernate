PagePanels.widgets = {
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"500px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"150px"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						panel1: ["wm.Panel", {"width":"100%","height":"63px","horizontalAlign":"center","verticalAlign":"top"}, {}, {
							borderButton: ["wm.Button", {"caption":"Turn off borders","width":"140px","height":"25px"}, {"onclick":"borderButtonClick"}],
							onButton: ["wm.Button", {"caption":"Turn on borders","width":"140px","height":"25px"}, {"onclick":"onButtonClick"}]
						}],
						layoutContent1: ["wm.Content", {"height":"100%","margin":"10","content":"panelText"}, {}]
					}],
					spacer12: ["wm.Spacer", {"width":"10px"}, {}],
					panel2: ["wm.Panel", {"width":"100%","height":"250px","horizontalAlign":"left","verticalAlign":"top","border":"5","borderColor":"#999999","scrollX":true,"scrollY":true}, {}, {
						panel3: ["wm.Panel", {"width":"100%","height":"126px","horizontalAlign":"left","verticalAlign":"top","border":"5","layoutKind":"left-to-right","borderColor":"red"}, {}, {
							label5: ["wm.Label", {"caption":"This panel is set to lay out widgets left-to-right.","height":"70px","width":"100px","singleLine":false}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							label2: ["wm.Label", {"_classes":{"domNode":["wm_BackgroundColor_Green","wm_FontColor_White"]},"caption":"Widget 1","height":"100px","width":"100px","margin":"4"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							label3: ["wm.Label", {"_classes":{"domNode":["wm_FontColor_White","wm_BackgroundColor_Blue"]},"caption":"Widget 1","height":"100px","width":"100px","margin":"4"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							label4: ["wm.Label", {"_classes":{"domNode":["wm_FontColor_White","wm_BackgroundColor_Purple"]},"caption":"Widget 1","height":"100px","width":"100px","margin":"4"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}]
						}],
						panel4: ["wm.Panel", {"width":"100%","height":"100%","horizontalAlign":"left","verticalAlign":"top","border":"5","layoutKind":"left-to-right","borderColor":"blue"}, {}, {
							panel5: ["wm.Panel", {"width":"100%","height":"100%","horizontalAlign":"left","verticalAlign":"top","border":"5","borderColor":"green"}, {}, {
								label6: ["wm.Label", {"caption":"This panel is set to lay out widgets top-to-bottom.","height":"53px","width":"100%","singleLine":false}, {}, {
									format: ["wm.DataFormatter", {}, {}]
								}],
								textEditor1: ["wm.TextEditor", {"caption":"textEditor1","width":"200px"}, {}, {
									editor: ["wm._TextEditor", {}, {}]
								}],
								checkBoxEditor1: ["wm.CheckBoxEditor", {"caption":"checkBoxEditor1","captionSize":"90%","width":"200px"}, {}, {
									editor: ["wm._CheckBoxEditor", {}, {}]
								}],
								radioButtonEditor1: ["wm.RadioButtonEditor", {"width":"200px","caption":"radioButtonEditor1","captionSize":"90%"}, {}, {
									editor: ["wm._RadioButtonEditor", {}, {}]
								}],
								radioButtonEditor2: ["wm.RadioButtonEditor", {"width":"200px","caption":"radioButtonEditor1","captionSize":"90%"}, {}, {
									editor: ["wm._RadioButtonEditor", {}, {}]
								}]
							}],
							panel6: ["wm.Panel", {"width":"100%","height":"100%","horizontalAlign":"left","verticalAlign":"top","border":"5","borderColor":"purple"}, {}, {
								label7: ["wm.Label", {"caption":"This panel is set to lay out widgets top-to-bottom.","height":"53px","width":"100%","singleLine":false}, {}, {
									format: ["wm.DataFormatter", {}, {}]
								}],
								calendar1: ["wm.dijit.Calendar", {"width":"100%"}, {}],
								sliderEditor1: ["wm.SliderEditor", {"width":"100%","caption":"sliderEditor1"}, {}, {
									editor: ["wm._SliderEditor", {}, {}]
								}],
								textAreaEditor1: ["wm.TextAreaEditor", {"height":"100%","width":"100%","caption":"textAreaEditor1"}, {}, {
									editor: ["wm._TextAreaEditor", {}, {}]
								}]
							}]
						}]
					}],
					spacer10: ["wm.Spacer", {"width":"10px"}, {}],
					pictureWidgetFlex: ["wm.Picture", {"height":"100%","width":"150px","source":"resources/images/panel.gif"}, {}, {
						binding: ["wm.Binding", {}, {}, {
							wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/panel.gif\""}, {}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"panelJSCode"}, {}]
				}]
			}]
		}]
	}]
}