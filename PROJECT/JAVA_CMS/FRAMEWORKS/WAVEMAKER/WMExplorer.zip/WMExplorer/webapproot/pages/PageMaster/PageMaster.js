dojo.declare("PageMaster", wm.Page, {
  start: function() {
 
  },
  // This function gets called by the onclick event for the buttonSelect widget 
  buttonSelectClick: function(inSender, inEvent) {
    try {
       // Set row to select in dataGrid
       var rowNum = this.selectEditor1.getDataValue();
       this.customerDataGrid1.select(rowNum-1);             
    } catch(e) {
      console.error('ERROR IN buttonStateClick: ' + e); 
    } 
  },
  // This function gets called by the onclick event for the buttonClear widget  
  buttonClearClick: function(inSender, inEvent) {
    try {
       // Clear select editor
       this.selectEditor1.clear();
       // Clear selection in dataGrid
       this.customerDataGrid1.clearSelection();    
    } catch(e) {
      console.error('ERROR IN buttonClearClick: ' + e); 
    } 
  },

  _end: 0
});