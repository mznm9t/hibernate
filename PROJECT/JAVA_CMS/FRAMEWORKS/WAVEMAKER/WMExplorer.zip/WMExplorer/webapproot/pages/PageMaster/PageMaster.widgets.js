PageMaster.widgets = {
	custPurchasesSvcVar: ["wm.ServiceVariable", {"service":"gurudb","operation":"purchaseByCustomer","startUpdate":true}, {}, {
		input: ["wm.ServiceInput", {"type":"purchaseByCustomerInputs"}, {}]
	}],
	updateSvcVar: ["wm.ServiceVariable", {"service":"gurudb","operation":"updatePurchase"}, {}, {
		input: ["wm.ServiceInput", {"type":"updatePurchaseInputs"}, {}]
	}],
	doEventsVar: ["wm.Variable", {"type":"BooleanData"}, {}],
	purchaseLiveVariable1: ["wm.LiveVariable", {"liveSource":"app.purchaseLiveView1"}, {}, {
		binding: ["wm.Binding", {}, {}, {
			wire: ["wm.Wire", {"targetProperty":"filter.customer.state","source":"selectEditor1.dataValue"}, {}]
		}]
	}],
	purchaseVar: ["wm.Variable", {"type":"com.data.Purchase"}, {}],
	customerLiveVariable1: ["wm.LiveVariable", {"liveSource":"app.customerLiveView1"}, {}],
	customerLiveVariable2: ["wm.LiveVariable", {"liveSource":"app.customerLiveView2"}, {}],
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"600px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px","height":"100%"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						panel1: ["wm.Panel", {"width":"100%","height":"80px","horizontalAlign":"center","verticalAlign":"top"}, {}, {
							selectEditor1: ["wm.SelectEditor", {"caption":"Row"}, {}, {
								editor: ["wm._SelectEditor", {"options":"1, 2, 3, 4, 5","displayField":"name","dataField":"dataValue"}, {}, {
									optionsVar: ["wm.Variable", {"type":"EntryData"}, {}]
								}]
							}],
							buttonSelect: ["wm.Button", {"caption":"Select Row","width":"140px","height":"25px"}, {"onclick":"buttonSelectClick"}],
							buttonClear: ["wm.Button", {"caption":"Clear Selection","width":"140px","height":"25px"}, {"onclick":"buttonClearClick"}]
						}],
						layoutContent1: ["wm.Content", {"height":"202px","margin":"10","content":"masterText"}, {}],
						picture1: ["wm.Picture", {"height":"100%","width":"100%","source":"resources/images/master.gif"}, {}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/master.gif\""}, {}]
							}]
						}]
					}],
					spacer12: ["wm.Spacer", {"width":"30px"}, {}],
					panel2: ["wm.Panel", {"width":"100%","height":"100%","border":"5","horizontalAlign":"left","verticalAlign":"top","borderColor":"#999999"}, {}, {
						customerLivePanel1: ["wm.LivePanel", {"verticalAlign":"top","horizontalAlign":"left"}, {}, {
							customerDataGrid1: ["wm.DataGrid", {"height":"176px"}, {}, {
								binding: ["wm.Binding", {}, {}, {
									wire: ["wm.Wire", {"targetProperty":"dataSet","expression":undefined,"source":"customerLiveVariable2"}, {}]
								}],
								name1: ["wm.DataGridColumn", {"field":"name","index":3,"caption":"Name","autoSize":undefined,"columnWidth":"196px"}, {}, {
									format: ["wm.DataFormatter", {}, {}]
								}],
								state1: ["wm.DataGridColumn", {"field":"state","index":4,"caption":"State","autoSize":undefined}, {}, {
									format: ["wm.DataFormatter", {}, {}]
								}]
							}],
							customerLiveForm1: ["wm.LiveForm", {"verticalAlign":"top","horizontalAlign":"left","readonly":true,"fitToContent":true,"height":"132px"}, {"onSuccess":"customerLiveVariable2"}, {
								binding: ["wm.Binding", {}, {}, {
									wire: ["wm.Wire", {"targetProperty":"dataSet","expression":undefined,"source":"customerDataGrid1.selectedItem"}, {}]
								}],
								custidEditor1: ["wm.Editor", {"caption":"Custid","display":"Number","readonly":true,"formField":"custid","width":"100%","height":"26px"}, {}, {
									editor: ["wm._NumberEditor", {"required":true}, {}]
								}],
								nameEditor1: ["wm.Editor", {"caption":"Name","readonly":true,"formField":"name","width":"100%","height":"26px"}, {}, {
									editor: ["wm._TextEditor", {}, {}]
								}],
								stateEditor1: ["wm.Editor", {"caption":"State","readonly":true,"formField":"state","width":"100%","height":"26px"}, {}, {
									editor: ["wm._TextEditor", {}, {}]
								}],
								descriptionEditor1: ["wm.Editor", {"caption":"Description","readonly":true,"formField":"description","width":"100%","height":"52px","singleLine":false}, {}, {
									editor: ["wm._TextEditor", {}, {}]
								}],
								editPanel1: ["wm.EditPanel", {"liveForm":"customerLiveForm1","savePanel":"savePanel1","operationPanel":"operationPanel1","showing":false}, {}, {
									savePanel1: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right","horizontalAlign":"right","showing":false}, {}, {
										saveButton1: ["wm.Button", {"caption":"Save","width":"70px","height":"100%"}, {"onclick":"editPanel1.saveData"}, {
											binding: ["wm.Binding", {}, {}, {
												wire: ["wm.Wire", {"targetProperty":"disabled","expression":undefined,"source":"editPanel1.formInvalid"}, {}]
											}]
										}],
										cancelButton1: ["wm.Button", {"caption":"Cancel","width":"70px","height":"100%"}, {"onclick":"editPanel1.cancelEdit"}]
									}],
									operationPanel1: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right","horizontalAlign":"right"}, {}, {
										newButton1: ["wm.Button", {"caption":"New","width":"70px","height":"100%"}, {"onclick":"editPanel1.beginDataInsert"}],
										updateButton1: ["wm.Button", {"caption":"Update","width":"70px","height":"100%","disabled":true}, {"onclick":"editPanel1.beginDataUpdate"}, {
											binding: ["wm.Binding", {}, {}, {
												wire: ["wm.Wire", {"targetProperty":"disabled","expression":undefined,"source":"editPanel1.formUneditable"}, {}]
											}]
										}],
										deleteButton1: ["wm.Button", {"caption":"Delete","width":"70px","height":"100%","disabled":true}, {"onclick":"editPanel1.deleteData"}, {
											binding: ["wm.Binding", {}, {}, {
												wire: ["wm.Wire", {"targetProperty":"disabled","expression":undefined,"source":"editPanel1.formUneditable"}, {}]
											}]
										}]
									}]
								}]
							}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"filterJSCode"}, {}]
				}]
			}]
		}]
	}]
}