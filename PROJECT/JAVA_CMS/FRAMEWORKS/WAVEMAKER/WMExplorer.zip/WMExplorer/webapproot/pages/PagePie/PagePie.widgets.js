PagePie.widgets = {
	custPurchasesSvcVar: ["wm.ServiceVariable", {"service":"gurudb","operation":"purchaseByCustomer","startUpdate":true}, {}, {
		input: ["wm.ServiceInput", {"type":"purchaseByCustomerInputs"}, {}]
	}],
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"600px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px","height":"100%"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						panel1: ["wm.Panel", {"width":"100%","height":"58px","horizontalAlign":"center","verticalAlign":"top"}, {}, {
							buttonBar: ["wm.Button", {"caption":"Bar Chart","width":"140px","height":"25px"}, {"onclick":"buttonBarClick"}],
							buttonPie: ["wm.Button", {"caption":"Pie Chart","width":"140px","height":"25px"}, {"onclick":"buttonPieClick"}]
						}],
						layoutContent1: ["wm.Content", {"height":"218px","margin":"5","content":"pieText"}, {}],
						picture1: ["wm.Picture", {"height":"100%","width":"100%","source":"resources/images/pie.gif"}, {}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/pie.gif\""}, {}]
							}]
						}]
					}],
					spacer12: ["wm.Spacer", {"width":"30px"}, {}],
					panel2: ["wm.Panel", {"width":"100%","height":"100%","border":"5","horizontalAlign":"left","verticalAlign":"top","borderColor":"#999999"}, {}, {
						dojoChart1: ["wm.DojoChart", {"height":"300px","width":"100%","border":"5","xAxis":"name","yAxis":"value","gap":10,"borderColor":"#222222","theme":"Bahamation","chartType":"Pie"}, {}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"targetProperty":"dataSet","source":"custPurchasesSvcVar"}, {}]
							}]
						}],
						dataGrid1: ["wm.DataGrid", {"border":"5","borderColor":"#666666"}, {}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"targetProperty":"dataSet","source":"custPurchasesSvcVar","expression":undefined}, {}]
							}],
							value1: ["wm.DataGridColumn", {"field":"value","index":1,"caption":"value","display":"Number"}, {}, {
								format: ["wm.NumberFormatter", {}, {}]
							}],
							name1: ["wm.DataGridColumn", {"field":"name","caption":"name"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"pieJSCode"}, {}]
				}]
			}]
		}]
	}]
}