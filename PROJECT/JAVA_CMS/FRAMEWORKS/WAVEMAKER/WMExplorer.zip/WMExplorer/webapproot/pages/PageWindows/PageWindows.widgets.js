PageWindows.widgets = {
	custPurchasesSvcVar: ["wm.ServiceVariable", {"service":"gurudb","operation":"purchaseByCustomer","startUpdate":true}, {}, {
		input: ["wm.ServiceInput", {"type":"purchaseByCustomerInputs"}, {}]
	}],
	updateSvcVar: ["wm.ServiceVariable", {"service":"gurudb","operation":"updatePurchase"}, {}, {
		input: ["wm.ServiceInput", {"type":"updatePurchaseInputs"}, {}]
	}],
	purchaseLiveVariable1: ["wm.LiveVariable", {"liveSource":"app.purchaseLiveView1"}, {}, {
		binding: ["wm.Binding", {}, {}, {
			wire: ["wm.Wire", {"targetProperty":"filter.customer.state","source":"selectEditor1.dataValue"}, {}]
		}]
	}],
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"600px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px","height":"100%"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						panel1: ["wm.Panel", {"width":"100%","height":"80px","horizontalAlign":"center","verticalAlign":"top"}, {}, {
							buttonPopup: ["wm.Button", {"caption":"Popup Window","width":"140px","height":"25px"}, {"onclick":"buttonPopupClick"}],
							buttonAlert: ["wm.Button", {"caption":"Alert Popup","width":"140px","height":"25px"}, {"onclick":"buttonAlertClick"}]
						}],
						layoutContent1: ["wm.Content", {"height":"202px","margin":"10","content":"popupText"}, {}]
					}],
					spacer12: ["wm.Spacer", {"width":"30px"}, {}],
					panel2: ["wm.Panel", {"width":"100%","height":"100%","border":"5","horizontalAlign":"left","verticalAlign":"top","borderColor":"#999999"}, {}, {
						label2: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_14px"]},"caption":"Click on any row!","height":"32px","width":"100%"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						purchaseDataGrid: ["wm.DataGrid", {"border":"5","borderColor":"#666666"}, {"onSelected":"purchaseDataGridSelected"}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"targetProperty":"dataSet","source":"purchaseLiveVariable1","expression":undefined}, {}],
								wire1: ["wm.Wire", {"targetProperty":"dataSet","source":"purchaseDataGrid.selectedItem","targetId":"app.purchaseVar"}, {}],
								wire2: ["wm.Wire", {"targetProperty":"filter.orderid","source":"purchaseDataGrid.selectedItem.orderid","targetId":"app.purchaseSelectVar"}, {}]
							}],
							orderdate1: ["wm.DataGridColumn", {"field":"orderdate","index":2,"display":"Date","caption":"Orderdate","autoSize":undefined}, {}, {
								format: ["wm.DateFormatter", {}, {}]
							}],
							ordervalue1: ["wm.DataGridColumn", {"field":"ordervalue","index":3,"display":"Number","caption":"Ordervalue","autoSize":undefined,"columnWidth":"77px"}, {}, {
								format: ["wm.NumberFormatter", {}, {}]
							}],
							customerName1: ["wm.DataGridColumn", {"field":"customer.name","caption":"Customer Name","autoSize":undefined,"columnWidth":"149px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}],
							customerState1: ["wm.DataGridColumn", {"field":"customer.state","index":1,"caption":"State","autoSize":undefined,"columnWidth":"70px"}, {}, {
								format: ["wm.DataFormatter", {}, {}]
							}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"popupJSCode"}, {}]
				}]
			}]
		}]
	}]
}