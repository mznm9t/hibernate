dojo.declare("PageBar", wm.Page, {
  start: function() {
 
  },
  chartEvents: function(inSender, inEvent) {
    try {
       // Pick random invoice to update and random purchase amount
       var randPurchase = Math.ceil(Math.random()*8);
       this.updateSvcVar.input.setValue("orderidvar", randPurchase);
       var randValue = Math.ceil(Math.random()*200);
       // console.log('Invoice = '+randPurchase+' Value = '+ randValue);
       this.updateSvcVar.input.setValue("newvaluevar", randValue);   
       // Update invoice
       this.updateSvcVar.update();
       // Now update the data for the chart
       this.custPurchasesSvcVar.update();  
       // console.log(this.doEventsVar.getValue("dataValue"));       
    } catch(e) {
      console.error('ERROR IN chartEvents: ' + e); 
    } 
  },
  // This function gets called by the onclick event for the buttonStart widget  
  buttonStartClick: function(inSender, inEvent) {
    try {
       this.chartEvents();      
    } catch(e) {
      console.error('ERROR IN buttonStartClick: ' + e); 
    } 
  },
  _end: 0
});