PageMenu.widgets = {
	custPurchasesSvcVar: ["wm.ServiceVariable", {"service":"gurudb","operation":"purchaseByCustomer","startUpdate":true}, {}, {
		input: ["wm.ServiceInput", {"type":"purchaseByCustomerInputs"}, {}]
	}],
	layoutBox1: ["wm.Layout", {"height":"100%"}, {}, {
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				panel9: ["wm.Panel", {"width":"100%","height":"600px","layoutKind":"left-to-right"}, {}, {
					panel10: ["wm.Panel", {"width":"200px","height":"100%"}, {}, {
						label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_16px","wm_BackgroundColor_LightGray"]},"caption":"Try It!","height":"32px","width":"96px"}, {}, {
							format: ["wm.DataFormatter", {}, {}]
						}],
						panel1: ["wm.Panel", {"width":"100%","height":"63px","horizontalAlign":"center","verticalAlign":"top"}, {}, {
							verticalButton: ["wm.Button", {"caption":"Vertical Menu","width":"96px","height":"25px"}, {"onclick":"verticalButtonClick"}],
							horizButton: ["wm.Button", {"caption":"Horizontal menu","width":"96px","height":"25px"}, {"onclick":"horizButtonClick"}]
						}],
						layoutContent1: ["wm.Content", {"height":"160px","margin":"10","content":"menuText"}, {}],
						picture1: ["wm.Picture", {"height":"100%","width":"100%","source":"resources/images/menu.gif"}, {}, {
							binding: ["wm.Binding", {}, {}, {
								wire: ["wm.Wire", {"targetProperty":"source","expression":"\"resources/images/menu.gif\""}, {}]
							}]
						}]
					}],
					spacer12: ["wm.Spacer", {"width":"30px"}, {}],
					panel2: ["wm.Panel", {"width":"100%","height":"100%","horizontalAlign":"left","verticalAlign":"top","border":"5","borderColor":"#999999"}, {}, {
						panel5: ["wm.Panel", {"width":"100%","height":"100%","horizontalAlign":"left","verticalAlign":"top"}, {}, {
							exampleMenu: ["wm.DojoMenu", {"_classes":{"domNode":["wm_FontSizePx_20px"]},"structure":"{\"items\":[{\"label\":\"File\",\"children\":[{\"label\":\"This\"},{\"label\":\"That\"},{\"label\":\"Other\"}]},{\"label\":\"Jazz\",\"children\":[{\"label\":\"Bebop\"},{\"label\":\"Swing\"},{\"label\":\"Free\"}]},{\"label\":\"More\",\"children\":[{\"label\":\"Country\"},{\"label\":\"Blue Grass\"},{\"label\":\"Blues\"}]},{\"label\":\"About\"},{\"label\":\"Help\"}]}","menu":"File>This,That,Other\nJazz>Bebop,Swing,Free\nMore>Country,Blue Grass, Blues\nAbout\nHelp\n\t","eventList":[{"label":"File","children":[{"label":"This"},{"label":"That"},{"label":"Other"}],"onClick":""},{"label":"This","onClick":""},{"label":"That","onClick":undefined},{"label":"Other","onClick":undefined},{"label":"Jazz","children":[{"label":"Bebop"},{"label":"Swing"},{"label":"Free"}],"onClick":undefined},{"label":"Bebop","onClick":undefined},{"label":"Swing","onClick":undefined},{"label":"Free","onClick":undefined},{"label":"More","children":[{"label":"Country"},{"label":"Blue Grass"},{"label":"Blues"}],"onClick":undefined},{"label":"Country","onClick":undefined},{"label":"Blue Grass","onClick":undefined},{"label":"Blues","onClick":undefined},{"label":"About","onClick":undefined},{"label":"Help","onClick":"onDojoMenuHelpClick"}]}, {}],
							panel4: ["wm.Panel", {"width":"100%","height":"100%","horizontalAlign":"left","verticalAlign":"top"}, {}, {
								label2: ["wm.Label", {"caption":"Clicking menu item displays which item was selected","height":"48px","width":"100%"}, {}, {
									format: ["wm.DataFormatter", {}, {}]
								}]
							}]
						}]
					}]
				}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","width":"100px"}, {}, {
				panel11: ["wm.Panel", {"width":"100%","height":"100%","layoutKind":"left-to-right"}, {}, {
					spacer11: ["wm.Spacer", {"width":"22px"}, {}],
					contentJavascript: ["wm.Content", {"content":"menuJSCode"}, {}]
				}]
			}]
		}]
	}]
}