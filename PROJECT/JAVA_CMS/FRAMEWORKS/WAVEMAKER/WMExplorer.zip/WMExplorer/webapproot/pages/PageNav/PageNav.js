dojo.declare("PageNav", wm.Page, {
  start: function() {
 
  },
  // This function gets called by the onclick event for the buttonInsertwidget 
  buttonInsertClick: function(inSender, inEvent) {
    try {
       // Set the liveform mode to start an insert operation for a customer
       this.customerLiveForm1.beginDataInsert();             
    } catch(e) {
      console.error('ERROR IN buttonStateClick: ' + e); 
    } 
  },
  // This function gets called by the onclick event for the buttonUpdate widget  
  buttonUpdateClick: function(inSender, inEvent) {
    try {
       // Check if there is already a selected row in datagrid
       if (this.customerDataGrid1.hasSelection() == false) {
          alert('You must select a row before beginning the update operation');
       }
       // Set the liveform mode to start an insert operation for a customer
       this.customerLiveForm1.beginDataUpdate();          
    } catch(e) {
      console.error('ERROR IN buttonClearClick: ' + e); 
    } 
  },

  _end: 0
});