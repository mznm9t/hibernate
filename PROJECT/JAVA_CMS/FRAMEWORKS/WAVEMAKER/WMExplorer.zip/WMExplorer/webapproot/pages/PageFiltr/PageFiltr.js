dojo.declare("PageFiltr", wm.Page, {
  start: function() {
 
  },
  // This function gets called by the onclick event for the buttonClear widget  
  buttonClearClick: function(inSender, inEvent) {
    try {
       // Clear select editor
       this.selectEditor1.clear();
       // Clear live var filter
       this.purchaseVar.setValue("customer.state", undefined);
       this.purchaseLiveVarFilter.setFilter(this.purchaseVar);
       // Update live var to reflect new filter     
       this.purchaseLiveVarFilter.update();       
    } catch(e) {
      console.error('ERROR IN buttonClearClick: ' + e); 
    } 
  },

  _end: 0
});