popUpPage.widgets = {
	layoutBox1: ["wm.Layout", {"height":"100%","border":"5","width":"100%","horizontalAlign":"left","verticalAlign":"top"}, {}, {
		label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_20px","wm_FontColor_White","wm_BackgroundColor_LightBlue"]},"caption":"This is a popup page","height":"32px","width":"100%"}, {}, {
			format: ["wm.DataFormatter", {}, {}]
		}],
		tabLayers1: ["wm.TabLayers", {}, {}, {
			layer1: ["wm.Layer", {"caption":"Visual Example","horizontalAlign":"left","verticalAlign":"top"}, {}, {
				liveForm1: ["wm.LiveForm", {"height":"186px","verticalAlign":"top","horizontalAlign":"left","readonly":true,"fitToContent":true}, {}, {
					binding: ["wm.Binding", {}, {}, {
						wire: ["wm.Wire", {"targetProperty":"dataSet","source":"app.purchaseSelectVar","expression":undefined}, {}],
						wire1: ["wm.Wire", {"targetProperty":"dataOutput.customer","source":"customerRelatedEditor1.dataOutput","expression":undefined}, {}]
					}],
					customerRelatedEditor1: ["wm.RelatedEditor", {"formField":"customer","lock":true,"fitToContent":true,"height":"106px"}, {}, {
						binding: ["wm.Binding", {}, {}, {
							wire: ["wm.Wire", {"targetProperty":"dataSet","source":"app.purchaseSelectVar.customer","expression":undefined}, {}]
						}],
						nameEditor1: ["wm.Editor", {"caption":"Name","readonly":true,"formField":"name","width":"100%","height":"26px"}, {}, {
							editor: ["wm._TextEditor", {}, {}]
						}],
						custidEditor1: ["wm.Editor", {"caption":"Custid","display":"Number","readonly":true,"formField":"custid","width":"100%","height":"26px"}, {}, {
							editor: ["wm._NumberEditor", {"required":true}, {}]
						}],
						descriptionEditor1: ["wm.Editor", {"caption":"Description","readonly":true,"formField":"description","width":"100%","height":"26px"}, {}, {
							editor: ["wm._TextEditor", {}, {}]
						}],
						stateEditor1: ["wm.Editor", {"caption":"State","readonly":true,"formField":"state","width":"100%","height":"26px"}, {}, {
							editor: ["wm._TextEditor", {}, {}]
						}]
					}],
					orderdateEditor1: ["wm.Editor", {"caption":"Orderdate","display":"Date","readonly":true,"formField":"orderdate","width":"100%","height":"26px"}, {}, {
						editor: ["wm._DateEditor", {"required":true}, {}]
					}],
					orderidEditor1: ["wm.Editor", {"caption":"Orderid","display":"Number","readonly":true,"formField":"orderid","width":"100%","height":"26px"}, {}, {
						editor: ["wm._NumberEditor", {"required":true}, {}]
					}],
					ordervalueEditor1: ["wm.Editor", {"caption":"Ordervalue","display":"Number","readonly":true,"formField":"ordervalue","width":"100%","height":"26px"}, {}, {
						editor: ["wm._NumberEditor", {}, {}]
					}]
				}],
				dismissButton: ["wm.Button", {"caption":"Dismiss","width":"96px","height":"32px"}, {"onclick":"dismissButtonClick"}]
			}],
			layer2: ["wm.Layer", {"caption":"JavaScript Example","horizontalAlign":"left","verticalAlign":"top","border":"10"}, {}, {
				content1: ["wm.Content", {"height":"100%","content":"dismissJSCode","border":"5"}, {}]
			}]
		}]
	}]
}