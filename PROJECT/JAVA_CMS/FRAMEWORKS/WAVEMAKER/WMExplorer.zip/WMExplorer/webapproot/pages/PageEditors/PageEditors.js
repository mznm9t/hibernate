dojo.declare("PageEditors", wm.Page, {
  start: function() {
    
  },
  // This function gets called when the value of an editor widget changes
  checkBoxEditor1Change: function(inSender, inDisplayValue, inDataValue) {
    try {
       this.checkBoxLabel.setCaption(this.checkBoxEditor1.getDataValue());
    } catch(e) {
      console.error('ERROR IN checkBoxEditor1Change: ' + e); 
    } 
  },
  currencyEditor1Change: function(inSender, inDisplayValue, inDataValue) {
    try {
        this.currencyLabel.setCaption(this.currencyEditor1.getDataValue());  
      
    } catch(e) {
      console.error('ERROR IN currencyEditor1Change: ' + e); 
    } 
  },
  dateEditor1Change: function(inSender, inDisplayValue, inDataValue) {
    try {
       this.dateLabel.setCaption(this.dateEditor1.getDataValue());     
      
    } catch(e) {
      console.error('ERROR IN dateEditor1Change: ' + e); 
    } 
  },
  numberEditor1Change: function(inSender, inDisplayValue, inDataValue) {
    try {
       this.numberLabel.setCaption(this.numberEditor1.getDataValue());
      
    } catch(e) {
      console.error('ERROR IN numberEditor1Change: ' + e); 
    } 
  },
  textEditor1Change: function(inSender, inDisplayValue, inDataValue) {
    try {
        this.textLabel.setCaption(this.textEditor1.getDataValue());
      
    } catch(e) {
      console.error('ERROR IN textEditor1Change: ' + e); 
    } 
  },
  onRadioButtonEditorChange: function(inSender, inDisplayValue, inDataValue) {
    try {
        this.radioButtonLabel.setCaption(this.radioButtonEditor1.getGroupValue());     
      
    } catch(e) {
      console.error('ERROR IN onRadioButtonEditorChange: ' + e); 
    } 
  },
  sliderEditor1Change: function(inSender, inDisplayValue, inDataValue) {
    try {
       this.sliderLabel.setCaption(this.sliderEditor1.getDataValue());     
      
    } catch(e) {
      console.error('ERROR IN sliderEditor1Change: ' + e); 
    } 
  },
  _end: 0
});