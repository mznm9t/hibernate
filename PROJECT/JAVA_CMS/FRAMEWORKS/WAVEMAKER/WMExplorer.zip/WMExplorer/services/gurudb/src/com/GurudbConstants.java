
package com;



/**
 *  Query names for service "gurudb"
 *  11/17/2009 11:56:00
 * 
 */
public class GurudbConstants {

    public final static String purchaseByCustomerQueryName = "purchaseByCustomer";
    public final static String updatePurchaseQueryName = "updatePurchase";
    public final static String getCustomerByIdQueryName = "getCustomerById";

    private GurudbConstants() {
        throw new UnsupportedOperationException();
    }

}
