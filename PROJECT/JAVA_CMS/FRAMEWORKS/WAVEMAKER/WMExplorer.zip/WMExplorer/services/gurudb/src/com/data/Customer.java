
package com.data;

import java.util.HashSet;
import java.util.Set;


/**
 *  gurudb.Customer
 *  11/17/2009 11:54:36
 * 
 */
public class Customer {

    private Integer custid;
    private com.data.Customer customer;
    private String name;
    private String state;
    private String description;
    private Set<com.data.Customer> customers = new HashSet<com.data.Customer>();
    private Set<com.data.Purchase> purchases = new HashSet<com.data.Purchase>();

    public Customer() {
    }

    public Customer(Integer custid, String name, String state, String description) {
        this.custid = custid;
        this.name = name;
        this.state = state;
        this.description = description;
    }

    public Customer(Integer custid, com.data.Customer customer, String name, String state, String description, Set<com.data.Customer> customers, Set<com.data.Purchase> purchases) {
        this.custid = custid;
        this.customer = customer;
        this.name = name;
        this.state = state;
        this.description = description;
        this.customers = customers;
        this.purchases = purchases;
    }

    public Integer getCustid() {
        return custid;
    }

    public void setCustid(Integer custid) {
        this.custid = custid;
    }

    public com.data.Customer getCustomer() {
        return customer;
    }

    public void setCustomer(com.data.Customer customer) {
        this.customer = customer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<com.data.Customer> getCustomers() {
        return customers;
    }

    public void setCustomers(Set<com.data.Customer> customers) {
        this.customers = customers;
    }

    public Set<com.data.Purchase> getPurchases() {
        return purchases;
    }

    public void setPurchases(Set<com.data.Purchase> purchases) {
        this.purchases = purchases;
    }

}
