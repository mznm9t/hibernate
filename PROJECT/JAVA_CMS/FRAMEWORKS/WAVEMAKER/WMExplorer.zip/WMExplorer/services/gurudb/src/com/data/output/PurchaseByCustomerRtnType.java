
package com.data.output;



/**
 * Generated for query "purchaseByCustomer" on 11/17/2009 11:54:39
 * 
 */
public class PurchaseByCustomerRtnType {

    private String name;
    private Long value;

    public PurchaseByCustomerRtnType() {
    }

    public PurchaseByCustomerRtnType(String name, Long value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getValue() {
        return value;
    }

    public void setValue(Long value) {
        this.value = value;
    }

}
