
package com.data;

import java.util.Date;


/**
 *  gurudb.Purchase
 *  11/17/2009 11:54:36
 * 
 */
public class Purchase {

    private Integer orderid;
    private Customer customer;
    private Date orderdate;
    private Integer ordervalue;

    public Purchase() {
    }

    public Purchase(Integer orderid, Date orderdate, Integer ordervalue) {
        this.orderid = orderid;
        this.orderdate = orderdate;
        this.ordervalue = ordervalue;
    }

    public Purchase(Integer orderid, Customer customer, Date orderdate, Integer ordervalue) {
        this.orderid = orderid;
        this.customer = customer;
        this.orderdate = orderdate;
        this.ordervalue = ordervalue;
    }

    public Integer getOrderid() {
        return orderid;
    }

    public void setOrderid(Integer orderid) {
        this.orderid = orderid;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getOrderdate() {
        return orderdate;
    }

    public void setOrderdate(Date orderdate) {
        this.orderdate = orderdate;
    }

    public Integer getOrdervalue() {
        return ordervalue;
    }

    public void setOrdervalue(Integer ordervalue) {
        this.ordervalue = ordervalue;
    }

}
